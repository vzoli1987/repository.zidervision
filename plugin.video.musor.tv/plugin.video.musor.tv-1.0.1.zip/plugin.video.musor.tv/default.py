# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs
import requests
from bs4 import BeautifulSoup
import sys, urllib.parse, re, json, os, time

# --- KONFIGURÁCIÓ ---
BASE_URL = "https://musor.tv"
HANDLE = int(sys.argv[1])
CACHE_FILE = xbmcvfs.translatePath('special://temp/musortv_cache.json')
CACHE_TIME = 600 

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[plugin.video.musortv] {msg}", level)

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
})

def get_html(url):
    log(f"Lekérés: {url}")
    
    # --- FIX VÁRAKOZÁS (A kérésed alapján) ---
    time.sleep(0.5) 

    # Cache logika
    cache_data = {}
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
        except: pass

    if url in cache_data and (time.time() - cache_data[url]['timestamp'] < CACHE_TIME):
        log("CACHE találat.")
        return cache_data[url]['content']

    try:
        resp = session.get(url, timeout=15)
        log(f"Válasz: {resp.status_code}")
        if resp.status_code != 200: return None
        html = resp.text
        
        # Cache mentése
        cache_data[url] = {'timestamp': time.time(), 'content': html}
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f)
            
        return html
    except Exception as e:
        log(f"Hiba a lekérésnél: {str(e)}", xbmc.LOGERROR)
        return None

def list_categories():
    cats = [
        ("Romantikus filmek", "/romantikus_filmek"),
        ("Filmek", "/filmek"),
        ("Vígjátékok", "/vigjatekok"),
        ("Krimi filmek", "/krimi_filmek"),
        ("Mai filmek (Összes)", "/mai-musor-film")
    ]
    for name, path in cats:
        url = f"{sys.argv[0]}?action=list&url={urllib.parse.quote(BASE_URL + path)}"
        li = xbmcgui.ListItem(label=name)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_programs(target_url):
    html = get_html(target_url)
    if not html: return

    soup = BeautifulSoup(html, 'html.parser')
    # A musor.tv-n a konkrét műsorok általában 'section' vagy specifikus div-ek
    items = soup.select('section.showevent, div.prog_entry') 
    
    if not items:
        # Ha a select nem találna semmit, megpróbáljuk a régebbi módszert
        items = soup.find_all('section')

    for item in items:
        try:
            title_tag = item.select_one('.showeventtitle a, .title a')
            if not title_tag: continue
                
            title = title_tag.text.strip()
            link = title_tag['href']
            if not link.startswith('http'): link = BASE_URL + link

            # Időpont keresése
            time_tag = item.select_one('.showeventtime, .time')
            time_match = re.search(r'(\d{2}:\d{2})', time_tag.text) if time_tag else None
            time_str = time_match.group(1) if time_match else "--:--"

            # Csatorna keresése
            channel = "TV"
            channel_img = item.select_one('.showeventchannel img, .channel_img')
            if channel_img and channel_img.get('alt'):
                channel = channel_img['alt']

            display_label = f"[COLOR orange]{time_str}[/COLOR] | [B]{title}[/B] ([COLOR lightblue]{channel}[/COLOR])"
            
            u = f"{sys.argv[0]}?action=play&url={urllib.parse.quote(link)}"
            li = xbmcgui.ListItem(label=display_label)
            
            # Infó tag beállítása Kodi 19+ kompatibilis módon
            info = li.getVideoInfoTag()
            info.setTitle(title)
            info.setPlot(f"Csatorna: {channel}\nIdőpont: {time_str}")

            xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=False)
            
        except Exception as e:
            log(f"Elem feldolgozási hiba: {e}")
            continue

    xbmcplugin.endOfDirectory(HANDLE)

def remove_accents(text):
    accents = {
        'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ö': 'o', 'ő': 'o',
        'ú': 'u', 'ü': 'u', 'ű': 'u', 'Á': 'A', 'É': 'E', 'Í': 'I',
        'Ó': 'O', 'Ö': 'O', 'Ő': 'O', 'Ú': 'U', 'Ü': 'U', 'Ű': 'U'
    }
    for char, replacement in accents.items():
        text = text.replace(char, replacement)
    return text

def play_video(url):
    """Ez fut le, ha simán rákattintasz a műsorra (bal klikk)."""
    html = get_html(url)
    if not html: return

    soup = BeautifulSoup(html, 'html.parser')
    title_tag = soup.find('h1') or soup.select_one('.showeventtitle')
    
    if title_tag:
        title = title_tag.text.strip()
        clean_title = title.split('(')[0].split(':')[0].strip()
        
        # Választómenü, hogy ne csak egy dolog történhessen
        dialog = xbmcgui.Dialog()
        ret = dialog.select(f"{clean_title}", ["Keresés az STB.hu-n", "YouTube Előzetes"])
        
        if ret == 0:
            stb_path = f"plugin://plugin.video.stb_hu/?action=get_search_items&search_text={urllib.parse.quote_plus(clean_title)}"
            xbmc.executebuiltin(f"Container.Update({stb_path})")
        elif ret == 1:
            encoded_yt = urllib.parse.quote_plus(remove_accents(clean_title) + " elozetes")
            yt_path = f"plugin://plugin.video.youtube/kodion/search/query/?q={encoded_yt}"
            xbmc.executebuiltin(f"ActivateWindow(Videos,{yt_path},return)")

def router(paramstring):
    # Paraméterek tisztítása
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')
    
    if action == 'list':
        list_programs(params.get('url'))
    elif action == 'play':
        play_video(params.get('url'))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2])