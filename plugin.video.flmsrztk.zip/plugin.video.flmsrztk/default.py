# -*- coding: utf-8 -*-
import sys
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Resolveurl importálása
try:
    import resolveurl
except ImportError:
    resolveurl = None

# Addon alapadatok
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME}] {msg}", level)

def get_html(url):
    """Segédfüggvény a HTML letöltéséhez"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        return urllib.request.urlopen(req, timeout=15).read().decode('utf-8')
    except Exception as e:
        log(f"HTML letöltési hiba ({url}): {e}", xbmc.LOGERROR)
        return ""

def get_embed_url(page_url):
    """Kinyeri a rejtett videó kulcsot és az embed URL-t"""
    html = get_html(page_url)
    if not html: return None

    # 1. Kulcs kinyerése (pl. 'tre218')
    key_match = re.search(r'onclick=["\']?askPassword\s*\(\s*this\s*,\s*["\']([^"\']+)["\']\s*\)', html, re.IGNORECASE)
    if not key_match:
        log("Nem található videó kulcs az oldalon.", xbmc.LOGERROR)
        return None
    
    video_key = key_match.group(1)
    log(f"Kinyert videó kulcs: '{video_key}'")

    # 2. JavaScript fájl letöltése
    js_url = "https://www.filmek-sorozatok.hu/wp-content/themes/tortuga/assets/js/videopass2.js"
    js_content = get_html(js_url)
    if not js_content: return None

    # 3. URL kinyerése a JS fájlból
    pattern = rf"['\"]{re.escape(video_key)}['\"]:\s*['\"]([^'\"]+)['\"]"
    url_match = re.search(pattern, js_content)
    if not url_match:
        log(f"Nem található URL a '{video_key}' kulcshoz.", xbmc.LOGERROR)
        return None
    
    video_path = url_match.group(1)
    
    # 4. URL formázása
    if video_path.startswith("//"):
        return "https:" + video_path
    elif video_path.startswith("/"):
        return "https://www.filmek-sorozatok.hu" + video_path
    return video_path

def scrape_movies(category_url):
    """
    Kigyűjti a filmeket egy kategória oldalról.
    Visszaad egy listát: [{'title': ..., 'url': ..., 'thumb': ...}, ...]
    """
    html = get_html(category_url)
    if not html: return []

    movies = []
    # WordPress article blokkok keresése
    articles = re.findall(r'<article[^>]*>(.*?)</article>', html, re.DOTALL | re.IGNORECASE)
    
    for art in articles:
        # Cím és URL kinyerése az entry-title-ből
        title_match = re.search(r'<h[1-6][^>]*class="[^"]*entry-title[^"]*"[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', art, re.DOTALL | re.IGNORECASE)
        if not title_match:
            continue
        
        movie_url = title_match.group(1)
        # HTML tagek eltávolítása a címből
        movie_title = re.sub(r'<[^>]+>', '', title_match.group(2)).strip()
        
        # Borítókép kinyerése
        img_match = re.search(r'<img[^>]*class="[^"]*wp-post-image[^"]*"[^>]*src="([^"]*)"', art, re.IGNORECASE)
        if not img_match:
            img_match = re.search(r'<img[^>]*src="([^"]*)"', art, re.IGNORECASE)
        
        thumb = img_match.group(1) if img_match else ""
        
        movies.append({'title': movie_title, 'url': movie_url, 'thumb': thumb})
        
    return movies

def list_movies(category_url):
    """Megjeleníti a filmeket a Kodiban"""
    movies = scrape_movies(category_url)
    
    if not movies:
        xbmcgui.Dialog().ok(ADDON_NAME, "Nem található film ezen az oldalon.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for movie in movies:
        play_url = f"{BASE_URL}?action=play&url={urllib.parse.quote(movie['url'], safe='')}"
        
        li = xbmcgui.ListItem(label=movie['title'])
        li.setArt({'thumb': movie['thumb'], 'icon': movie['thumb'], 'poster': movie['thumb']})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': movie['title'], 'plot': movie['title']})
        
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
    
    # Következő oldal gomb (ha van pagination)
    # Egyszerűsített példa: feltételezzük, hogy van következő oldal, ha az URL-ben van /page/
    # Egy éles addonban a HTML-ből kellene kinyerni a "next" linket.
    # Itt most csak a lista lezárása történik.
    
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(page_url):
    """Lejátszás indítása a ResolveURL segítségével"""
    if not resolveurl:
        xbmcgui.Dialog().ok(ADDON_NAME, "Hiba: A 'script.module.resolveurl' nincs telepítve!")
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Videó link előkészítése...")
    
    try:
        embed_url = get_embed_url(page_url)
        dialog.update(50, "Videó link feloldása (ResolveURL)...")
        
        if not embed_url:
            dialog.close()
            xbmcgui.Dialog().ok(ADDON_NAME, "Nem sikerült megtalálni a videó forrását.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

        stream_url = resolveurl.resolve(embed_url)
        dialog.close()
        
        if stream_url:
            log(f"Sikeres feloldás: {stream_url}")
            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            log("A resolveurl nem tudta feloldani a linket.", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, "A videó forrása jelenleg nem elérhető.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            
    except Exception as e:
        dialog.close()
        log(f"Hiba a lejátszás során: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f"Hiba történt: {str(e)}")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def router(paramstring):
    """Útválasztó a műveletekhez"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    
    if action == 'play':
        play_video(params.get('url'))
    elif action == 'list':
        list_movies(params.get('url'))
    else:
        # Alapértelmezett: Online filmek kategória
        list_movies("https://www.filmek-sorozatok.hu/online-filmek/")

if __name__ == '__main__':
    router(sys.argv[2][1:])