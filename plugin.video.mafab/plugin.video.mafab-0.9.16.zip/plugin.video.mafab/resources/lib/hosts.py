# -*- coding: utf-8 -*-
"""Host search and playback built on the pluggable source adapters.

The adapter layer (resources/lib/adapters), net.py and aggregator.py come from
plugin.video.mozipremierek; the functions below are lifted from its default.py
so a Mafab.hu movie is looked up by title on the same sources and played the
same way (ZiderVision/ResolveURL resolvers, per-row hand-off to other add-ons).
"""
from __future__ import absolute_import

import importlib
import threading
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import re
import sys
import time
import uuid
from difflib import SequenceMatcher
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .adapters import ADAPTERS
from .aggregator import _year, group_movies, normalize_title
from .perf import timed

class _LazyModule(object):
    """Importing resolveurl takes seconds on Android: do it only when a resolver is really needed."""

    def __init__(self, name):
        self._name = name
        self._mod = False

    def _load(self):
        if self._mod is False:
            try:
                with timed('import %s' % self._name):
                    self._mod = importlib.import_module(self._name)
            except Exception:  # noqa: BLE001 - not installed / broken: behave as absent
                self._mod = None
        return self._mod

    def __bool__(self):
        return self._load() is not None

    def __getattr__(self, attr):
        module = self._load()
        if module is None:
            raise AttributeError(attr)
        return getattr(module, attr)


resolveurl = _LazyModule('resolveurl')
zidervisionurlresolver = _LazyModule('zidervisionurlresolver')

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1])
PLUGIN_BASE = sys.argv[0]
HOST_CACHE_SCHEMA = 5
META = {}  # filled by main.film() with the movie's art/plot so host rows look like the movie


def plugin_url(action, **params):
    query = {'action': action}
    query.update(params)
    return PLUGIN_BASE + '?' + urlencode(query)



def set_video_info(item, info):
    """Set Kodi video metadata through InfoTagVideo, with a legacy fallback."""
    try:
        tag = item.getVideoInfoTag()
        if not tag:
            raise AttributeError('Kodi InfoTagVideo unavailable')
        setters = {
            'title': 'setTitle', 'originaltitle': 'setOriginalTitle', 'mediatype': 'setMediaType',
            'plot': 'setPlot', 'year': 'setYear', 'duration': 'setDuration', 'mpaa': 'setMpaa',
            'imdbnumber': 'setIMDBNumber', 'premiered': 'setPremiered'
        }
        for key, setter_name in setters.items():
            if key in info and hasattr(tag, setter_name):
                getattr(tag, setter_name)(info[key])
        list_setters = {
            'genre': 'setGenres', 'director': 'setDirectors', 'cast': 'setCast',
            'country': 'setCountries', 'studio': 'setStudios'
        }
        for key, setter_name in list_setters.items():
            if key in info and hasattr(tag, setter_name):
                value = info[key]
                if not isinstance(value, list):
                    value = [x.strip() for x in str(value).split(',') if x.strip()]
                getattr(tag, setter_name)(value)
    except (AttributeError, TypeError):
        item.setInfo('video', info)




def quality_color(quality):
    """Same palette as the progress dialog: 4K purple, 1080p teal, 720p blue, HD green, SD grey, DVD orange, CAM red."""
    q = str(quality or '').upper()
    if '2160' in q or '4K' in q or 'UHD' in q:
        return 'FFBCA8E8'
    if '1080' in q or '1440' in q or '2K' in q:
        return 'FF72D5C9'
    if '720' in q:
        return 'FF77B5FF'
    if 'DVD' in q or 'BLU' in q or 'WEB' in q:
        return 'FFFFB86C'
    if 'CAM' in q or q.strip() in ('TS', 'TC', 'HDCAM', 'MOZIS'):
        return 'FFFF7777'
    if 'HD' in q:
        return 'FF66CC88'
    if '480' in q or '360' in q or 'SD' in q:
        return 'FFA7B0BA'
    return 'FF65758B'


def quality_counts():
    return {'4K': 0, '1080p': 0, '720p': 0, 'HD': 0, 'SD': 0, 'DVD': 0, 'CAM': 0, 'Egyéb': 0, 'Összesen': 0}


def source_quality_sort_key(source):
    quality = str(source.get('quality', '') or '').upper()
    if '2160' in quality or '4K' in quality or 'UHD' in quality:
        rank = 0
    elif '1440' in quality or '2K' in quality:
        rank = 1
    elif '1080' in quality:
        rank = 2
    elif '720' in quality:
        rank = 3
    elif 'HD' in quality:
        rank = 4
    elif 'DVD' in quality:
        rank = 5
    elif '480' in quality or '360' in quality or 'SD' in quality:
        rank = 6
    elif 'CAM' in quality or 'TS' == quality.strip():
        rank = 7
    else:
        rank = 8
    return (
        rank,
        str(source.get('adapter_name', '')).casefold(),
        str(source.get('host', '')).casefold(),
        str(source.get('language', '')).casefold()
    )


def add_quality_counts(counts, sources):
    for source in sources:
        quality = str(source.get('quality', '')).upper()
        if '2160' in quality or '4K' in quality:
            category = '4K'
        elif '1080' in quality:
            category = '1080p'
        elif '720' in quality:
            category = '720p'
        elif 'DVD' in quality:
            category = 'DVD'
        elif 'CAM' in quality or 'TS' == quality.strip():
            category = 'CAM'
        elif '480' in quality or '360' in quality or 'SD' in quality:
            category = 'SD'
        elif 'HD' in quality:
            category = 'HD'
        else:
            category = 'Egyéb'
        counts[category] += 1
        counts['Összesen'] += 1


def update_source_progress(progress, percent, page_name, completed, total, counts, phase):
    percent = max(0, min(100, int(percent)))
    frames = ('[>   ]', '[=>  ]', '[==> ]', '[===>]')
    frame = frames[(int(completed) + percent) % len(frames)]
    line1 = '[COLOR FFBCA8E8]%s[/COLOR]  [COLOR FF72D5C9]%s[/COLOR]  [COLOR FFFF9E64]%d%%[/COLOR]' % (
        phase, frame, percent
    )
    line2 = '[COLOR FFE6ECF2]Aktuális:[/COLOR] [COLOR FFD9B15F]%s[/COLOR]  [COLOR FF72D5C9]%d/%d[/COLOR]' % (
        page_name, max(0, int(completed)), max(1, int(total))
    )
    line3 = (
        '[COLOR FFBCA8E8]4K %d[/COLOR] | '
        '[COLOR FF72D5C9]1080p %d[/COLOR] | '
        '[COLOR FF77B5FF]720p %d[/COLOR] | '
        '[COLOR FF66CC88]HD %d[/COLOR] | '
        '[COLOR FFA7B0BA]SD %d[/COLOR] | '
        '[COLOR FFFFB86C]DVD %d[/COLOR] | '
        '[COLOR FFFF7777]CAM %d[/COLOR]  '
        '[COLOR FFE6ECF2]Össz: [COLOR FFFF9E64]%d[/COLOR][/COLOR]'
    ) % (
        counts['4K'], counts['1080p'], counts['720p'], counts['HD'],
        counts['SD'], counts['DVD'], counts['CAM'], counts['Összesen']
    )
    # Kodi 21's Python DialogProgress.update accepts percent plus one message.
    progress.update(percent, '\n'.join((line1, line2, line3)))


def save_source_queue(title, sources):
    token = uuid.uuid4().hex
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    xbmcvfs.mkdirs(profile)
    with open(os.path.join(profile, 'source_queue_%s.json' % token), 'w', encoding='utf-8') as target:
        json.dump({'title': title, 'sources': sources}, target, ensure_ascii=False)
    return token


def load_source_queue(token):
    if not re.match(r'^[a-f0-9]{32}$', token or ''):
        return None
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    path = os.path.join(profile, 'source_queue_%s.json' % token)
    try:
        with open(path, 'r', encoding='utf-8') as source:
            data = json.load(source)
        return data if isinstance(data.get('sources'), list) else None
    except (OSError, ValueError, TypeError):
        return None


def source_cache_path(title, movie_path):
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    xbmcvfs.mkdirs(profile)
    cache_key = hashlib.sha256((movie_path + '|' + normalize_title(title)).encode('utf-8')).hexdigest()
    return os.path.join(profile, 'host_cache_%s.json' % cache_key)


def load_host_cache(title, movie_path):
    try:
        with open(source_cache_path(title, movie_path), 'r', encoding='utf-8') as cache_file:
            cached = json.load(cache_file)
        if cached.get('schema') != HOST_CACHE_SCHEMA:
            return None
        sources = cached.get('sources')
        if not isinstance(sources, list):
            return None
        age = time.time() - float(cached.get('fetched_at', 0))
        ttl = 3600 if sources else 120
        return sources if 0 <= age < ttl else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def save_host_cache(title, movie_path, sources):
    path = source_cache_path(title, movie_path)
    temp_path = path + '.tmp'
    with open(temp_path, 'w', encoding='utf-8') as cache_file:
        json.dump({'schema': HOST_CACHE_SCHEMA, 'fetched_at': time.time(), 'sources': sources}, cache_file, ensure_ascii=False)
    os.replace(temp_path, path)


def add_adapter_hosts(title, path):
    """Automatically search providers on movie open, showing live progress and host rows."""
    cached_sources = load_host_cache(title, path)
    if cached_sources is not None:
        return render_host_rows(title, cached_sources)

    records = []
    errors = []
    counts = quality_counts()
    progress = xbmcgui.DialogProgress()
    progress.create('HOSTKERESÉS  |  %s' % title, 'Forrásoldalak előkészítése...')
    cancelled = False
    total_adapters = len(ADAPTERS)
    def search_one(adapter):
        with timed('adapter search %s' % adapter.name):
            try:
                return adapter, adapter.search(title) or [], None
            except Exception as exc:  # noqa: BLE001
                return adapter, [], exc
    try:
        update_source_progress(progress, 5, 'minden forrás', 0, total_adapters, counts, 'FORRÁSKERESÉS')
        done = 0
        pool = ThreadPoolExecutor(max_workers=max(1, total_adapters))
        try:
            futures = [pool.submit(search_one, adapter) for adapter in ADAPTERS]
            pending = set(futures)
            while pending and not cancelled:
                finished = {f for f in pending if f.done()}
                pending -= finished
                for fut in finished:
                    adapter, found, exc = fut.result()
                    done += 1
                    if exc is not None:
                        errors.append('%s: %s' % (adapter.name, exc))
                        xbmc.log('%s adapter search failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
                    update_source_progress(
                        progress, int(25 * done / max(1, total_adapters)),
                        adapter.name, done, total_adapters, counts, 'FORRÁSKERESÉS'
                    )
                if progress.iscanceled():
                    cancelled = True
                elif pending:
                    time.sleep(0.1)
            for fut in futures:     # keep adapter order stable
                if fut.done():
                    records.extend(fut.result()[1])
        finally:
            _stop_pool(pool)
    except Exception as exc:
        errors.append('Adapter keresés: %s' % exc)
        xbmc.log('%s progress/search error: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)

    wanted = normalize_title(title)
    groups = group_movies(records)
    want_year = _year(META.get('year'))
    if want_year:    # same title, other year = another film (e.g. an older "A fenevad"): drop it
        groups = [g for g in groups if not g.get('year') or abs(int(g['year']) - int(want_year)) <= 1]
    matches = [group for group in groups if normalize_title(group.get('title', '')) == wanted]
    if not matches and not cancelled and wanted:
        stopwords = {'a', 'az', 'the', 'and', 'of', 'at', 'to', 'in', 'on', 'for'}
        wanted_tokens = set(wanted.split()) - stopwords
        ranked = []
        for group in groups:
            candidate = normalize_title(group.get('title', ''))
            candidate_tokens = set(candidate.split()) - stopwords
            shared = wanted_tokens & candidate_tokens
            overlap = len(shared) / float(max(1, len(wanted_tokens)))
            similarity = SequenceMatcher(None, wanted, candidate).ratio()
            if similarity >= 0.72 or (shared and similarity >= 0.40 and overlap >= 0.30):
                ranked.append((max(similarity, overlap), group))
        ranked.sort(key=lambda entry: entry[0], reverse=True)
        candidates = [group for _, group in ranked[:6]]
        if len(candidates) == 1:
            candidate_title = candidates[0].get('title', 'Ismeretlen cím')
            if xbmcgui.Dialog().yesno(
                'Nem pontos címegyezés', 'A forrás ezt találta: %s' % candidate_title,
                'Ez a keresett film: %s?' % title
            ):
                matches = candidates
        elif candidates:
            choice = xbmcgui.Dialog().select('Lehetséges címek', [g.get('title', 'Film') for g in candidates])
            if choice >= 0:
                matches = [candidates[choice]]

    sources = []
    if matches and not cancelled:
        group = matches[0]
        by_id = {adapter.adapter_id: adapter for adapter in ADAPTERS}
        tasks = [(movie, by_id.get(movie.get('adapter_id'))) for movie in group.get('movies', [])]
        tasks = [(movie, adapter) for movie, adapter in tasks if adapter]
        seen = {}

        def sources_one(movie, adapter):
            with timed('adapter sources %s' % adapter.name):
                try:
                    found = adapter.sources(movie) or []
                    for source in found:
                        source['adapter_name'] = source.get('adapter_name') or adapter.name
                    return adapter, found, None
                except Exception as exc:  # noqa: BLE001
                    return adapter, [], exc
        try:
            pool = ThreadPoolExecutor(max_workers=max(1, len(tasks)))
            try:
                futures = [pool.submit(sources_one, movie, adapter) for movie, adapter in tasks]
                pending, done = set(futures), 0
                while pending and not cancelled:
                    finished = {f for f in pending if f.done()}
                    pending -= finished
                    for fut in finished:
                        done += 1
                        update_source_progress(
                            progress, 25 + int(75 * done / max(1, len(tasks))), fut.result()[0].name,
                            done, len(tasks), counts, 'HOSTOK KIOLVASÁSA'
                        )
                    if progress.iscanceled():
                        cancelled = True
                    elif pending:
                        time.sleep(0.1)
                for fut in futures:     # adapter order stays stable
                    if not fut.done():
                        continue
                    adapter, found, exc = fut.result()
                    if exc is not None:
                        errors.append('%s: %s' % (adapter.name, exc))
                        xbmc.log('%s source listing failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
                        continue
                    accepted = []
                    for source in found:
                        if source.get('source_url') and not source.get('parent_resolve_only'):
                            key = ('embed', str(source['source_url']).casefold())   # same embed from two adapters: one row
                        else:
                            key = (
                                source['adapter_name'], str(source.get('host', '')).casefold(),
                                str(source.get('quality', '')).casefold(), str(source.get('language', '')).casefold(),
                                str(source.get('source_url') or source.get('source_page_url') or source.get('play_url', '')).casefold()
                            )
                        if key not in seen:
                            seen[key] = source
                            sources.append(source)
                            accepted.append(source)
                        elif key[0] == 'embed' and source['adapter_name'] not in seen[key]['adapter_name'].split(' + '):
                            seen[key]['adapter_name'] += ' + ' + source['adapter_name']   # same row from a mirror site: show both names
                    add_quality_counts(counts, accepted)
            finally:
                _stop_pool(pool)
        except Exception as exc:
            errors.append('Forráslista: %s' % exc)
            xbmc.log('%s progress/source error: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
    progress.close()

    if not cancelled:
        try:
            save_host_cache(title, path, sources)
        except (OSError, TypeError, ValueError) as exc:
            xbmc.log('%s host cache save failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
    return render_host_rows(title, sources, cancelled, errors)


_SUPPORT = None
SUPPORT_TTL = 7 * 24 * 3600


def _support_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'host_support.json')


def _support_cache():
    """{domain: bool} remembered for a week, so the resolver module need not be imported to list hosts."""
    global _SUPPORT
    if _SUPPORT is None:
        _SUPPORT = {}
        try:
            path = _support_path()
            if os.path.exists(path) and time.time() - os.path.getmtime(path) < SUPPORT_TTL:
                with open(path, 'r', encoding='utf-8') as fh:
                    _SUPPORT = dict(json.load(fh))
        except Exception:  # noqa: BLE001
            _SUPPORT = {}
    return _SUPPORT


def _support_cache_save():
    try:
        with open(_support_path(), 'w', encoding='utf-8') as fh:
            json.dump(_SUPPORT, fh)
    except Exception:  # noqa: BLE001
        pass


def resolver_supports(source):
    """False only for a row whose embed link is known and resolveurl has no resolver for it.
    Rows that still need an embed lookup (parent_resolve_only), direct streams and raw players are kept."""
    url = source.get('source_url') or ''
    if (not url or source.get('parent_resolve_only') or source.get('direct_stream')
            or source.get('allow_raw_source') or not url.startswith(('http://', 'https://'))):
        return True
    domain = urlparse(url).netloc.lower()
    known = _support_cache()
    if domain in known:
        return known[domain]
    if not resolveurl:
        return True
    try:
        ok = bool(resolveurl.HostedMediaFile(url).valid_url())
    except Exception:  # noqa: BLE001 - a resolver bug must not hide the row
        return True
    known[domain] = ok
    _support_cache_save()
    return ok


def render_host_rows(title, sources, cancelled=False, errors=None):
    errors = errors or []
    hidden = 0
    try:
        only = ADDON.getSettingBool('only_resolvable')
    except Exception:  # noqa: BLE001
        only = False
    if only:
        kept = [src for src in sources if resolver_supports(src)]
        hidden, sources = len(sources) - len(kept), kept
    sources = sorted(sources, key=source_quality_sort_key)
    shown = '%s [COLOR FFFFD700](%s)[/COLOR]' % (title, META['year']) if META.get('year') else title
    header = xbmcgui.ListItem(label='[COLOR FF65758B]--- %s | FILMHOSTOK ---[/COLOR]' % shown)
    header.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url('noop'), header, False)
    if not sources:
        message = 'Nem találtam elérhető hostot ehhez a filmhez.'
        if cancelled:
            message = 'A hostkeresést megszakítottad.'
        elif errors:
            message += ' Egyes adapterek nem válaszoltak.'
        elif hidden:
            message += ' (%d host kiszűrve: a ResolveURL nem támogatja)' % hidden
        item = xbmcgui.ListItem(label='[COLOR FF9AA6B2]%s[/COLOR]' % message)
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('noop'), item, False)
        return

    token = save_source_queue(title, sources)
    for index, source in enumerate(sources):
        host = re.sub(r'\[/?COLOR[^\]]*\]', '', str(source.get('host', 'ismeretlen host')), flags=re.I)
        provider = re.sub(r'\[/?COLOR[^\]]*\]', '', str(source.get('adapter_name', 'FORRÁS')), flags=re.I)
        quality = re.sub(r'\[/?COLOR[^\]]*\]', '', str(source.get('quality', '') or 'N/A'), flags=re.I)
        language = re.sub(r'\[/?COLOR[^\]]*\]', '', str(source.get('language', '') or 'N/A'), flags=re.I)
        label = (
            '[COLOR %s][B]%s[/B][/COLOR]  |  [COLOR FFE6ECF2]%s[/COLOR]  |  '
            '[COLOR FFD9B15F]%s[/COLOR]  |  [COLOR FFBCA8E8]%s[/COLOR]'
        ) % (quality_color(quality), quality, host, provider, language)
        item = xbmcgui.ListItem(label=label)
        info = {'title': title, 'mediatype': 'movie'}
        if META.get('plot'):
            info['plot'] = META['plot']
        if META.get('year'):
            info['year'] = META['year']
        set_video_info(item, info)
        art = {}
        if META.get('poster'):
            art.update({'thumb': META['poster'], 'poster': META['poster']})
        if META.get('fanart'):
            art['fanart'] = META['fanart']
        if art:
            item.setArt(art)
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('play_sources', token=token, index=index), item, False)


def resolved_stream_url(result):
    if isinstance(result, dict):
        result = result.get('url') or result.get('stream_url') or ''
    elif isinstance(result, (tuple, list)):
        result = result[0] if result else ''
    if isinstance(result, str) and result.startswith(('http://', 'https://')):
        return result
    return ''


def play_sources(token, start_index):
    """Start with the clicked row, then move to later rows only on a resolve failure."""
    queue = load_source_queue(token)
    if not queue:
        xbmcgui.Dialog().notification('Mafab.hu', 'A forráslista lejárt; nyisd meg újra a filmet.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    title = queue.get('title', 'Film')
    sources = queue['sources']
    try:
        start_index = max(0, int(start_index))
    except (TypeError, ValueError):
        start_index = 0
    if start_index >= len(sources):
        xbmcgui.Dialog().notification('Mafab.hu', 'A kiválasztott forrássor már nem érhető el.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    progress = xbmcgui.DialogProgress()
    progress.create('Forrás ellenőrzése - %s' % title, 'Lejátszható host keresése indul...')
    remaining = len(sources) - start_index
    cancelled = False
    dead_hosts = set()      # domains that already timed out in this attempt: no point retrying each row
    try:
        for offset, index in enumerate(range(start_index, len(sources))):
            if progress.iscanceled():
                cancelled = True
                break
            source = sources[index]
            host = str(source.get('host', 'ismeretlen host'))
            adapter_name = str(source.get('adapter_name', 'forrás'))
            source_url = source.get('source_url', '')
            row_domain = urlparse(source_url).netloc.lower() if source_url else ''
            if row_domain and row_domain in dead_hosts:
                xbmc.log('%s skipping row %d (%s / %s): %s did not answer earlier' % (ADDON_ID, index + 1, adapter_name, host, row_domain), xbmc.LOGINFO)
                continue
            percent = int(offset * 100 / max(1, remaining))
            progress.update(
                percent,
                '[COLOR FFE6ECF2]Host-próba:[/COLOR] [COLOR FFFF9E64]%d/%d[/COLOR]\n'
                '[COLOR FF72D5C9]%s[/COLOR]  |  [COLOR FFD9B15F]%s[/COLOR]\n'
                '[COLOR FFE6ECF2]Embed betöltése, feloldás és elérhetőség ellenőrzése...[/COLOR]' % (
                    offset + 1, remaining, adapter_name, host
                )
            )
            xbmc.log('%s trying row %d/%d (%s / %s)' % (ADDON_ID, index + 1, len(sources), adapter_name, host), xbmc.LOGINFO)
            if not source_url:
                adapter_id = source.get('adapter_id', '')
                adapter = next((item for item in ADAPTERS if item.adapter_id == adapter_id), None)
                source_resolver = getattr(adapter, 'resolve_source_url', None) if adapter else None
                if source_resolver:
                    try:
                        source_url = run_limited(lambda: source_resolver(source), progress) or ''
                    except Exception as exc:
                        error_text = str(exc)
                        xbmc.log('%s embed extraction failed at row %d (%s / %s): %s' % (ADDON_ID, index + 1, adapter_name, host, exc), xbmc.LOGWARNING)
                        lowered_error = error_text.lower()
                        if any(marker in lowered_error for marker in ('cloudflare', 'verification', 'captcha')):
                            status = 'Cloudflare/ellenőrző oldal - nem kerüljük meg; következő forrás...'
                        elif '404' in lowered_error:
                            status = 'A beküldött link 404-es; következő host...'
                        else:
                            status = 'A link lekérése nem sikerült; következő host...'
                        progress.update(
                            percent,
                            '[COLOR FFE6ECF2]Host-próba:[/COLOR] [COLOR FFFF9E64]%d/%d[/COLOR]\n'
                            '[COLOR FF72D5C9]%s[/COLOR]  |  [COLOR FFD9B15F]%s[/COLOR]\n'
                            '[COLOR FFFF7777]%s[/COLOR]' % (offset + 1, remaining, adapter_name, host, status)
                        )
                        if source.get('parent_resolve_only'):
                            continue
                    if source_url:
                        embed_host = urlparse(source_url).netloc
                        progress.update(
                            percent,
                            '[COLOR FFE6ECF2]Host-próba:[/COLOR] [COLOR FFFF9E64]%d/%d[/COLOR]\n'
                            '[COLOR FF72D5C9]%s[/COLOR]  |  [COLOR FFD9B15F]%s => %s[/COLOR]\n'
                            '[COLOR FFE6ECF2]Feloldás és elérhetőség ellenőrzése...[/COLOR]' % (
                                offset + 1, remaining, adapter_name, host, embed_host
                            )
                        )
                        xbmc.log('%s extracted embed at row %d: %s' % (ADDON_ID, index + 1, embed_host), xbmc.LOGINFO)
                    elif source.get('parent_resolve_only'):
                        progress.update(
                            percent,
                            '[COLOR FFE6ECF2]Host-próba:[/COLOR] [COLOR FFFF9E64]%d/%d[/COLOR]\n'
                            '[COLOR FF72D5C9]%s[/COLOR]  |  [COLOR FFD9B15F]%s[/COLOR]\n'
                            '[COLOR FFFF7777]Nem érkezett használható embed URL; következő host...[/COLOR]' % (
                                offset + 1, remaining, adapter_name, host
                            )
                        )
                        continue
            stream = ''
            if source_url and source.get('direct_stream') and source_url.startswith(('http://', 'https://')):
                stream = source_url
            elif source_url and (zidervisionurlresolver or resolveurl):
                # every resolver gets its chance: a stream one of them returns may still be refused (403)
                soft_stream = ''
                for resolver_name in ('zidervision', 'resolveurl'):
                    candidate = ''
                    try:
                        if resolver_name == 'zidervision' and zidervisionurlresolver:
                            candidate = resolved_stream_url(run_limited(lambda: zidervisionurlresolver.resolve(source_url), progress))
                        elif resolver_name == 'resolveurl' and resolveurl:
                            media = resolveurl.HostedMediaFile(source_url)
                            try:    # ResolveURL's own link test dies on slow CDNs (17 s timeout) although the stream plays
                                # newer ResolveURL: returns (status, mimetype); older: a bool
                                media._HostedMediaFile__test_stream = lambda stream_url: (True, 'video/mp4')
                            except Exception:  # noqa: BLE001
                                pass
                            if media and media.valid_url():
                                try:
                                    candidate = resolved_stream_url(run_limited(media.resolve, progress))
                                except (TypeError, ValueError):     # the skipped link test had another shape: stock one
                                    media = resolveurl.HostedMediaFile(source_url)
                                    candidate = resolved_stream_url(run_limited(media.resolve, progress))
                    except Exception as exc:  # noqa: BLE001
                        xbmc.log('%s %s failed at row %d (%s / %s): %s' % (ADDON_ID, resolver_name, index + 1, adapter_name, host, exc), xbmc.LOGWARNING)
                        if is_network_failure(exc):
                            dead_hosts.add(row_domain)
                        candidate = ''
                    if not candidate:
                        continue
                    try:
                        usable = run_limited(lambda: stream_is_available(candidate), progress, 12)
                    except Exception:  # noqa: BLE001 - timeout / cancel
                        usable = False
                    if usable is True:
                        stream = candidate
                        break
                    if usable == 'refused' and not soft_stream:
                        soft_stream = candidate     # kept as a last resort: a 403 to our probe is not proof
                    xbmc.log('%s %s stream not usable at row %d (%s / %s); trying next resolver' % (ADDON_ID, resolver_name, index + 1, adapter_name, host), xbmc.LOGINFO)
                if not stream and soft_stream:
                    stream = soft_stream
                    xbmc.log('%s row %d (%s / %s): every probe was refused, handing the stream to the player anyway' % (ADDON_ID, index + 1, adapter_name, host), xbmc.LOGINFO)
            elif source_url and source.get('allow_raw_source') and source_url.startswith(('http://', 'https://')):
                # FilmDepo's supplied addon also passes the player URL through unchanged
                # when ResolveURL is not installed; availability checking still guards it.
                stream = source_url
            if stream:
                if source_url and not source.get('direct_stream') and (zidervisionurlresolver or resolveurl) and not (
                        source.get('allow_raw_source') and stream == source_url):
                    available = True        # a resolver's stream was verified above
                else:
                    try:
                        available = run_limited(lambda: stream_is_available(stream), progress, 12) is True
                    except Exception:  # noqa: BLE001 - timeout / cancel: treat as unavailable
                        available = False
                if available:
                    xbmc.log('%s resolved row %d (%s / %s)' % (ADDON_ID, index + 1, adapter_name, host), xbmc.LOGINFO)
                    progress.update(100, '[COLOR FF55C7C2]Forrás használható - lejátszás indítása:[/COLOR] [COLOR FFD9B15F]%s[/COLOR]' % host)
                    item = xbmcgui.ListItem(label=title, path=stream)
                    item.setProperty('IsPlayable', 'true')
                    set_video_info(item, {'title': title, 'mediatype': 'movie'})
                    xbmcplugin.setResolvedUrl(HANDLE, True, item)
                    return
                xbmc.log('%s resolved stream unavailable at row %d (%s / %s); continuing' % (ADDON_ID, index + 1, adapter_name, host), xbmc.LOGINFO)
            if source_url:
                xbmc.log('%s direct source unavailable at row %d (%s / %s); continuing' % (ADDON_ID, index + 1, adapter_name, host), xbmc.LOGINFO)
                if source.get('parent_resolve_only') and (source.get('direct_stream') or source.get('allow_raw_source') or zidervisionurlresolver or resolveurl):
                    continue
                if zidervisionurlresolver or resolveurl:
                    # the other add-on would run the very same resolver on the very same link
                    # (and wait for the same timeout again): move on instead
                    continue

            # Preserve row identity: delegate only to this row's own player route.
            fallback = source.get('play_url', '')
            if not fallback.startswith('plugin://'):
                continue
            addon_id = fallback[len('plugin://'):].split('/', 1)[0]
            if addon_id and not xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
                xbmc.log('%s skipped row %d (%s / %s): required addon %s is not installed' % (ADDON_ID, index + 1, adapter_name, host, addon_id), xbmc.LOGWARNING)
                continue
            xbmc.log('%s handing off clicked/fallback row %d (%s / %s) to %s' % (ADDON_ID, index + 1, adapter_name, host, addon_id), xbmc.LOGINFO)
            progress.update(100, '[COLOR FF55C7C2]Host átadása a lejátszónak:[/COLOR] [COLOR FFD9B15F]%s[/COLOR]' % host)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            xbmc.executebuiltin('PlayMedia(%s)' % fallback)
            return
        if cancelled:
            xbmcgui.Dialog().notification('Mafab.hu', 'A hostpróbát megszakítottad.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            xbmcgui.Dialog().notification('Mafab.hu', 'Egyik hostot sem sikerült feloldani.', xbmcgui.NOTIFICATION_ERROR, 4500)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    finally:
        progress.close()


RESOLVE_TIMEOUT = 25   # seconds a single host may block (embed fetch / resolver) before the next row is tried


def _stop_pool(pool):
    """Do not wait for stuck workers (Kodi's Python may be older than 3.9: no cancel_futures)."""
    try:
        pool.shutdown(wait=False, cancel_futures=True)
    except TypeError:
        pool.shutdown(wait=False)


class RowCancelled(Exception):
    pass


def run_limited(func, progress=None, timeout=RESOLVE_TIMEOUT):
    """Run a blocking call in a worker thread so Kodi's UI stays alive: the dialog's Cancel works
    and a host that hangs is dropped after `timeout` seconds instead of freezing Kodi."""
    box = {}

    def target():
        try:
            box['value'] = func()
        except BaseException as exc:  # noqa: BLE001 - re-raised in the caller
            box['error'] = exc
    worker = threading.Thread(target=target, daemon=True)
    worker.start()
    deadline = time.time() + timeout
    while worker.is_alive():
        if progress is not None and progress.iscanceled():
            raise RowCancelled()
        if time.time() > deadline:
            raise TimeoutError('no answer in %d s' % timeout)
        worker.join(0.2)
    if 'error' in box:
        raise box['error']
    return box.get('value')



def is_network_failure(exc):
    text = ('%s %s' % (type(exc).__name__, exc)).lower()
    return isinstance(exc, (TimeoutError, URLError, OSError)) or any(
        marker in text for marker in ('timed out', 'timeout', 'urlerror', 'connection', 'unreachable'))


def stream_is_available(url):
    """Lightweight availability check so a dead resolved link is skipped before playback."""
    target = url
    headers = {'User-Agent': 'Mozilla/5.0 (Kodi; plugin.video.mafab/0.2.0)', 'Range': 'bytes=0-0'}
    if '|' in url:
        target, raw_headers = url.split('|', 1)
        for key, values in parse_qs(raw_headers, keep_blank_values=True).items():
            if values:
                headers[key] = values[-1]
        headers['Range'] = 'bytes=0-0'
    request = Request(target, headers=headers)
    try:
        with urlopen(request, timeout=5) as response:
            content_type = response.headers.get('Content-Type', '').lower()
            if response.getcode() >= 400 or 'text/html' in content_type:
                return False
            response.read(1)
            return True
    except HTTPError as exc:
        # a refusal (401/403/404/410) is final; a slow CDN or a 5xx may still play in Kodi
        if exc.code in (401, 403):
            return 'refused'     # the probe was refused; Kodi's own request (other headers) may still work
        return exc.code not in (404, 410)
    except (URLError, TimeoutError, OSError, ValueError):
        return True     # no answer in time is not proof of a dead stream: let the player try


